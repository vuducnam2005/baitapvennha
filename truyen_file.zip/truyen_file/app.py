from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import rsa
import base64

app = Flask(__name__)
socketio = SocketIO(app, async_mode='threading')

# Tạo khóa RSA mặc định ban đầu
PUBLIC_KEY, PRIVATE_KEY = rsa.newkeys(2048)

@app.route("/")
def index():
    return render_template("index.html")  # frontend đã được đưa vào templates/index.html

@app.route("/generate_keys", methods=["POST"])
def generate_keys():
    global PUBLIC_KEY, PRIVATE_KEY
    PUBLIC_KEY, PRIVATE_KEY = rsa.newkeys(2048)
    return jsonify({
        "public_key": PUBLIC_KEY.save_pkcs1().decode(),
        "private_key": PRIVATE_KEY.save_pkcs1().decode()
    })

# Mã hóa dữ liệu
@socketio.on("encrypt")
def handle_encrypt(data):
    try:
        pubkey = rsa.PublicKey.load_pkcs1(data["public_key"].encode())
        encrypted = rsa.encrypt(data["data"].encode(), pubkey)
        encrypted_b64 = base64.b64encode(encrypted).decode()
        emit("encrypt_result", {"encrypted": encrypted_b64})
    except Exception as e:
        emit("encrypt_result", {"error": str(e)})

# Giải mã dữ liệu
@socketio.on("decrypt")
def handle_decrypt(data):
    try:
        privkey = rsa.PrivateKey.load_pkcs1(data["private_key"].encode())
        encrypted_bytes = base64.b64decode(data["encrypted"])
        decrypted = rsa.decrypt(encrypted_bytes, privkey).decode()
        emit("decrypt_result", {"decrypted": decrypted})
    except Exception as e:
        emit("decrypt_result", {"error": str(e)})

# Ký dữ liệu
@socketio.on("sign")
def handle_sign(data):
    try:
        privkey = rsa.PrivateKey.load_pkcs1(data["private_key"].encode())
        signature = rsa.sign(data["data"].encode(), privkey, 'SHA-256')
        signature_b64 = base64.b64encode(signature).decode()
        emit("sign_result", {"signature": signature_b64})
    except Exception as e:
        emit("sign_result", {"error": str(e)})

# Xác minh chữ ký
@socketio.on("verify")
def handle_verify(data):
    try:
        pubkey = rsa.PublicKey.load_pkcs1(data["public_key"].encode())
        signature = base64.b64decode(data["signature"])
        rsa.verify(data["data"].encode(), signature, pubkey)
        emit("verify_result", {"result": "✅ Chữ ký hợp lệ."})
    except Exception as e:
        emit("verify_result", {"result": f"❌ Không hợp lệ: {str(e)}"})

if __name__ == "__main__":
    socketio.run(app, debug=True)
